@extends('app')
@section('content')
<h1>Hello</h1>
{{-- <h1>{{$user->name}}</h1> --}}
@endsection